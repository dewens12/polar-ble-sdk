package com.polar.polarsdkecghrdemo;

public interface PlotterListener{
    void update();
}
